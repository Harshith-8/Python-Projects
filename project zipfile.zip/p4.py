# Simple GUI project using tkinter:-

# import tkinter as tk
# root = tk.Tk()
# root.geometry("430x150")
# label = tk.Label(root,text="Mr.Harsh",font=("Algerian",16),foreground="Red")
# label.pack()
# root.mainloop()


import tkinter as tk
def button_click():
    label.config(text="clicked")
root = tk.Tk()
root.geometry("200x100")
button = tk.Button(root,text='click here..',command=button_click)
button.pack()
label = tk.Label(root)
label.pack()
root.mainloop()