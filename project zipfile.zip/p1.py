# Converting text to audio file:-


from gtts import gTTS
from playsound import playsound
audio = "text.mp3"
language = 'en'
sp = gTTS(text="My name is Harshith",lang=language,slow=False)
sp.save(audio)
playsound(audio)
print("===Audio is playing===")