# Date picker using Simple GUI:-


import tkinter as tk
from tkinter import ttk
from tkcalendar import Calendar,DateEntry
def select_date():
    selected_date = cal.selection_get()
    date_label.config(text=f"selected Date:{selected_date:%d/%m/%y}",foreground="white",background="black")
root=tk.Tk()
root.title("Date pickup calender..")
root.config(background="#67e69c")
ttk.Style().configure("Tbutton",background="#FF69B4",foreground = "black")
ttk.Style().configure("Tlable",background="#1E90FF",foreground = "White")
cal = Calendar(root,selectmode = "day",date_pattern ="dd/mm/yyyy",background="#6f67e6")
date_label =  ttk.Label(root,text="selected Date:",font=("Algerian",16),foreground="white")
select_button = ttk.Button(root,text="select Date",command=select_date)
cal.pack(padx=10,pady=10)
date_label.pack(padx=10,pady=10)
select_button.pack(padx=10,pady=10)
root.mainloop()